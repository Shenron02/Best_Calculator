from calculator.gui.calculator_gui import CalculatorGUI

def main():
    app = CalculatorGUI()
    app.mainloop()

if __name__ == "__main__":
    main()