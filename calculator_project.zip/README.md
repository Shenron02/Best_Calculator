# Symbolic Inverse Trigonometric Calculator

A tkinter GUI calculator for computing symbolic inverse trig values of arcsin, arccos, and arctan.

## Usage

```bash
pip install -r requirements.txt
python main.py
```