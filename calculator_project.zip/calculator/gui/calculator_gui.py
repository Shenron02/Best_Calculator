import tkinter as tk
from tkinter import ttk, messagebox
import math
from calculator.core.symbolic_inverse_trig import symbolic_arcsin, symbolic_arccos, symbolic_arctan

class CalculatorGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Symbolic Inverse Trig Calculator")
        self.geometry("400x250")
        self.create_widgets()

    def create_widgets(self):
        ttk.Label(self, text="Value:").pack(pady=5)
        self.input_entry = ttk.Entry(self)
        self.input_entry.pack(pady=5)

        ttk.Label(self, text="Function:").pack(pady=5)
        self.func_var = tk.StringVar(value="arcsin")
        ttk.Combobox(self, textvariable=self.func_var, values=["arcsin", "arccos", "arctan"]).pack(pady=5)

        self.result_var = tk.StringVar(value="Result shows here")
        ttk.Label(self, textvariable=self.result_var, font=("Arial", 14)).pack(pady=10)

        ttk.Button(self, text="Calculate", command=self.calculate).pack(pady=10)

    def calculate(self):
        try:
            val = float(self.input_entry.get())
            func = self.func_var.get()

            if func == "arcsin":
                res = symbolic_arcsin(val)
            elif func == "arccos":
                res = symbolic_arccos(val)
            else:
                res = symbolic_arctan(val)

            if res is None:
                if func == 'arcsin':
                    res = f"Approx: {round(math.degrees(math.asin(val)), 6)}°"
                elif func == 'arccos':
                    res = f"Approx: {round(math.degrees(math.acos(val)), 6)}°"
                elif func == 'arctan':
                    res = f"Approx: {round(math.degrees(math.atan(val)), 6)}°"
            self.result_var.set(res)
        except Exception:
            messagebox.showerror("Input Error", "Please enter a valid number within domain.")

if __name__ == "__main__":
    app = CalculatorGUI()
    app.mainloop()