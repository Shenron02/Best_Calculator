import math
from typing import Optional

def symbolic_arcsin(value: float) -> Optional[str]:
    lookup = {
        0.5: "π/6",
        math.sqrt(2)/2: "π/4",
        math.sqrt(3)/2: "π/3",
        1.0: "π/2",
        0.0: "0",
        -0.5: "-π/6",
        -math.sqrt(2)/2: "-π/4",
        -math.sqrt(3)/2: "-π/3",
        -1.0: "-π/2",
    }
    rounded_val = round(value, 6)
    for k, v in lookup.items():
        if abs(rounded_val - round(k, 6)) < 1e-6:
            return v
    return None

def symbolic_arccos(value: float) -> Optional[str]:
    lookup = {
        0.5: "π/3",
        math.sqrt(2)/2: "π/4",
        math.sqrt(3)/2: "π/6",
        1.0: "0",
        0.0: "π/2",
        -0.5: "2π/3",
        -math.sqrt(2)/2: "3π/4",
        -math.sqrt(3)/2: "5π/6",
        -1.0: "π",
    }
    rounded_val = round(value, 6)
    for k, v in lookup.items():
        if abs(rounded_val - round(k, 6)) < 1e-6:
            return v
    return None

def symbolic_arctan(value: float) -> Optional[str]:
    lookup = {
        0.0: "0",
        1.0: "π/4",
        math.sqrt(3): "π/3",
        1/math.sqrt(3): "π/6",
        -1.0: "-π/4",
        -math.sqrt(3): "-π/3",
        -1/math.sqrt(3): "-π/6",
    }
    rounded_val = round(value, 6)
    for k, v in lookup.items():
        if abs(rounded_val - round(k, 6)) < 1e-6:
            return v
    return None